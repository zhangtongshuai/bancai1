require(['../common/common'],function(c){
    require(['jquery','template','md5','global','cookie','slider','base'],function($,template,md5,api){
        //联系人信息页面
        function contact(data,api,success) {
            $.ajax({
                type:"get",
                async:true,
                traditional :true,
                data: data,
                dataType: "json",
                url:api+'/api/contacts',
                contentType: "application/json; charset=utf-8",
                success : function(msg){
                    console.log(msg);
                    var Contact_data = msg;
                    var html = template("seller-content-contact",Contact_data);
                    document.getElementById('seller-content-cont').innerHTML = html;
                },
                error:function(){
                    alert('发生错误，请求数据失败！');
                }
            });
        }
                var user_id = $.cookie('user_id'),
                    access_token = $.cookie('access_token');

                var user_id = 1000000003,
                    access_token = "da2c29b1-0db9-434d-860d-93834ca0f576";
                var contactdata =  {
                    "user_id":user_id,
                    "access_token":access_token
                };
                contact(contactdata,"http://192.168.100.90/api");

    });
});



