require(['../common/common'], function(c) {
	require(['jquery', 'template', 'md5', 'global', 'layui', 'cookie', 'area', 'slider', 'base'], function($, template, md5, api, layui, cookie, area) {

		/**
		 * 数据渲染
		 */
		//获取用户信息
		var jhbCookie = $.cookie(),
			access_token = jhbCookie.access_token,
			user_id = jhbCookie.user_id;
		/**
		 * 交互效果
		 */
		//所有的全局变量
		var hSpan = $(".header-top-box h2").eq(1).find("span").text(), //获取消息右上角元素内容
			mcartNum = $(".header-top-box .m-cart span").text(), //获得购物车右上角元素内容
			lockKey = 0, //0表示没有自定义的参数，1表示有自定义的参数
			clickNum = 0; //表示自定义参数的数量
		var arr = [], //自定义参数数组
			brr = []; //删除undefined后的数组
		//消息和购物车右上角的数量显示隐藏
		if(parseInt(hSpan) != 0) {
			$(".header-top-box h2").eq(1).find("span").css({
				"visibility": 'visible'
			});
		}
		if(parseInt(mcartNum) != 0) {
			$(".header-top-box .m-cart span").css({
				"display": 'inline-block'
			});
		}

		// 二维码显示隐藏
		$(".buyer-header .user-info li").eq(3).mouseenter(function() {
			$(this).find("img").removeClass("hideen");
		}).mouseleave(function() {
			$(this).find("img").addClass("hideen");
		});
		
		//基本信息
		var cookieMsg = $.cookie();//卖家选择的发布产品的类型和名称
		//console.log(cookieMsg);
		$('.buyer-right-bottom.basemsg div.one').eq(0).find('span:nth-of-type(2)').html(cookieMsg.catagory);
		$('.buyer-right-bottom.basemsg div.one').eq(1).find('span:nth-of-type(2)').html(cookieMsg.pname);
		
		//自定义参数
		$('.user-defined span').eq(1).on("click", function() {
			var userDefined = '<div class="user-defined-demo"><span>参数名：</span><input type="text" id="argue-name-' + lockKey + '" value="" /><span>&nbsp;&nbsp;&nbsp;&nbsp;参数值：</span><input type="text" id="argue-value-' + lockKey + '" value="" /><i class="iconfont icon-garbagecan"></i></div>'
			$('.layui-form .user-defined-box').append(userDefined);
			++lockKey;
			arr.push("", "");
			console.log(arr)
		});
		$('.user-defined-box').on("click", 'i', function() {
			var index = parseInt($(this).prev().attr('id').split('-')[2]);
			$(this).parent().remove();
			arr.splice(2 * index, 2);
			console.log(arr.length)
		});


		//上传编辑器实例化
		var ue = UE.getEditor('editor');
		
		//获取并设置选中值
		$('#fabu').on("click", function() {
	        //基本信息的信息
	        var catagory = cookieMsg.catagory,
	        	pname = cookieMsg.pname,
	        	title = $('#publish-title').val(),
	        	keyword_old = $('#publish-keyword').val(),
	        	keyword = changeDouHao(keyword_old),
	        	sku_code = $('#product-key').val();
	        
	        //规格参数的信息
			var spec = $('#spec option:selected').text(),
				midu = $('#mi_du option:selected').text(),
				deng_ji = $('#deng_ji option:selected').text(),
				jiao_shui = $('#jiao_shui option:selected').text(),
				jia_quan = $('#jia_quan option:selected').text(),
				han_shui_lv = $('#han_shui_lv option:selected').text(),
				yong_tu = $('#yong_tu option:selected').text();

			//订货的信息
			var is_manage_kc = $('.buyer-right-bottom.order .layui-input-block').eq(0).find('input[type=radio]:checked').val(),
				unit = $('.buyer-right-bottom.order .layui-input-block').eq(1).find('input[type=radio]:checked').val(),
				kc_ammount = $('.buyer-right-bottom.order .layui-input-block').eq(2).find('input').val(),
				min_qd = $('.buyer-right-bottom.order .layui-input-block').eq(3).find('input').val(),
				is_yang_pin = $('.buyer-right-bottom.order .layui-input-block').eq(4).find('input[type=radio]:checked').val(),
				price = $('.buyer-right-bottom.order .layui-input-block').eq(5).find('input').val(),
				is_yj = $('.buyer-right-bottom.order .layui-input-block').eq(6).find('input[type=radio]:checked').val(),
				fee = $('.buyer-right-bottom.order .layui-input-block').eq(7).find('input').val(),
				province = $('#province option:selected').text(),
				city = $('#city option:selected').text(),
				district = $('#town option:selected').text();
			
			//产品展示的信息
			var piccLen = $('.buyer-right-bottom.product-zhan li.picc').length;
			
			//产品详情的信息
			var arrEditor = [],
				details;//产品详情
	        arrEditor.push(UE.getEditor('editor').getContent());
	        details = arrEditor.join("\n");
			
			
			if(lockKey == 0) {
				if(is_manage_kc == 1) {
					if('' == kc_ammount) {
						layer.msg('库存量没有填写');
						return false;
					}
					panduan();
				}else{
					panduan();
				}
				
				var publishObj = {
					'catagory': catagory,
					'pname': pname,
					'title': title,
					'keyword': keyword,
					'sku_code': sku_code,
					'spec': spec,
					'deng_ji': deng_ji,
					'jiao_shui': jiao_shui,
					'jia_quan': jia_quan,
					'midu': midu,
					'han_shui_lv': han_shui_lv,
					'is_manage_kc': is_manage_kc,
					'unit': unit,
					'kc_ammount': kc_ammount,
					'min_qd': min_qd,
					'is_yang_pin': is_yang_pin,
					'price': price,
					'is_yj': is_yj,
					'fee': fee,
					'province': province,
					'city': city,
					'district': district,
					'details': details
				};
				//console.log(publishObj);
				
				//发送数据到后台
				/*$.ajax({
					type: "post",
					url: api+"/api/FB_MDB?access_token="+ access_token +"&user_id="+ user_id,
					async: true,
					data: JSON.stringify(publishObj),
					dataType: 'json'
				}).then(function(publishData){
					console.log(publishData);
					layer.msg('发布成功');
					window.location.reload();
				});*/
				
				
			} else {
				//自定义参数的信息
				for(let i = 0; i < lockKey; i++) {
					if($('#argue-name-' + i)) {
						//console.log(i);
						arr[2 * i] = $('#argue-name-' + i).val();
						arr[2 * i + 1] = $('#argue-value-' + i).val();
					}
				}
				brr = [];//自定义参数的数据
				for(let i = 0; i < arr.length; i++) {
					if(typeof arr[i] != 'undefined') {
						brr.push(arr[i]);
					}
				}
				console.log(brr, lockKey);
				//自定义参数的信息
				var parameters = [],
					paraObj = {};
				for (let i=0; i<brr.length; i+=2) {
					paraObj = {};
					paraObj['para_name'] = brr[i];
					paraObj['para_value'] = brr[i+1];
					parameters.push(paraObj);
				}
				//console.log(parameters);
				
				if(is_manage_kc == 1) {
					if('' == kc_ammount) {
						layer.msg('库存量没有填写');
						return false;
					}
					panduan();
				}else{
					panduan();
				}
				
				var publishObj = {
					'catagory': catagory,
					'pname': pname,
					'title': title,
					'keyword': keyword,
					'sku_code': sku_code,
					'spec': spec,
					'deng_ji': deng_ji,
					'jiao_shui': jiao_shui,
					'jia_quan': jia_quan,
					'midu': midu,
					'han_shui_lv': han_shui_lv,
					'parameters': parameters,
					'is_manage_kc': is_manage_kc,
					'unit': unit,
					'kc_ammount': kc_ammount,
					'min_qd': min_qd,
					'is_yang_pin': is_yang_pin,
					'price': price,
					'is_yj': is_yj,
					'fee': fee,
					'province': province,
					'city': city,
					'district': district,
					'details': details
				};
				//console.log(publishObj);
				
				//发送数据到后台
				/*$.ajax({
					type: "post",
					url: api+"/api/FB_MDB?access_token="+ access_token +"&user_id="+ user_id,
					async: true,
					data: JSON.stringify(publishObj),
					dataType: 'json'
				}).then(function(publishData){
					console.log(publishData);
					layer.msg('发布成功');
					window.location.reload();
				});*/
				
			}
			
			//判断方法
			function panduan(){
				if('' == title) {
					layer.msg('标题没有填写');
				} else if('' == keyword) {
					layer.msg('关键字没有填写');
				} else if('' == spec) {
					layer.msg('规格没有选择');
				} else if('' == midu) {
					layer.msg('密度没有选择');
				} else if('' == jiao_shui) {
					layer.msg('胶水种类没有选择');
				} else if('' == deng_ji) {
					layer.msg('产品等级没有选择');
				} else if('' == jia_quan) {
					layer.msg('甲醛释放量没有选择');
				} else if('' == han_shui_lv) {
					layer.msg('含水率没有选择');
				} else if('' == yong_tu) {
					layer.msg('产品用途没有选择');
				} else if('' == min_qd) {
					layer.msg('起订量没有填写');
				} else if('' == price) {
					layer.msg('价格没有填写');
				} else if('' == fee) {
					layer.msg('运费没有填写');
				} else if('省份' == province) {
					layer.msg('省份没有选择');
				} else if('请选择' == city) {
					layer.msg('城市没有选择');
				} else if('请选择' == district) {
					layer.msg('区/县没有选择');
				} else if(piccLen == 0) {
					layer.msg('没有上传产品图片');
				} else if('' == details) {
					layer.msg('产品详情没有填写');
				} else if(5000 < details.length) {
					layer.msg('产品详情内容不能超过5000字符')
				}
			}
			
		});

		//左侧栏颜色改变
		$(".buyer-content .buyer-slider dl").eq(0).find("dd:nth-of-type(6)").find("a").css({
			"color": "#ff3c00"
		});
		
		//将中文逗号转换成英文逗号
		function changeDouHao(str){
			str=str.replace(/，/ig,',');
			return str;
		}
	});
});