require(['../common/common'], function(c) {
	require(['jquery', 'template', 'md5', 'global', 'layui', 'cookie', 'area', '../../../ueditor.all.min', '../../../ueditor.config', 'slider', 'base'], function($, template, md5, api, layui, cookie, area) {

		/**
		 * 数据渲染
		 */
		//获取用户信息
		var jhbCookie = $.cookie(),
			access_token = jhbCookie.access_token,
			user_id = jhbCookie.user_id;
		
		var user_id = 1000000006,
			access_token = "056f4368-690a-4820-a3ef-b6238f62d713";
		/**
		 * 交互效果
		 */
		//所有的全局变量
		var hSpan = $(".header-top-box h2").eq(1).find("span").text(), //获取消息右上角元素内容
			mcartNum = $(".header-top-box .m-cart span").text(), //获得购物车右上角元素内容
			lockKey = 0, //0表示没有自定义的参数，1表示有自定义的参数
			clickNum = 0; //表示自定义参数的数量
		var arr = [], //自定义参数数组
			brr = []; //删除undefined后的数组
		//消息和购物车右上角的数量显示隐藏
		if(parseInt(hSpan) != 0) {
			$(".header-top-box h2").eq(1).find("span").css({
				"visibility": 'visible'
			});
		}
		if(parseInt(mcartNum) != 0) {
			$(".header-top-box .m-cart span").css({
				"display": 'inline-block'
			});
		}

		// 二维码显示隐藏
		$(".buyer-header .user-info li").eq(3).mouseenter(function() {
			$(this).find("img").removeClass("hideen");
		}).mouseleave(function() {
			$(this).find("img").addClass("hideen");
		});
		
		//基本信息
		var cookieMsg = $.cookie();//卖家选择的发布产品的类型和名称
		//console.log(cookieMsg);
		$('.buyer-right-bottom.basemsg div.one').eq(0).find('span:nth-of-type(2)').html(cookieMsg.catagory);
		$('.buyer-right-bottom.basemsg div.one').eq(1).find('span:nth-of-type(2)').html(cookieMsg.pname);
		
		//自定义参数
		$('.user-defined span').eq(1).on("click", function() {
			var userDefined = '<div class="user-defined-demo"><span>参数名：</span><input type="text" id="argue-name-' + lockKey + '" value="" /><span>&nbsp;&nbsp;&nbsp;&nbsp;参数值：</span><input type="text" id="argue-value-' + lockKey + '" value="" /><i class="iconfont icon-garbagecan"></i></div>'
			$('.layui-form .user-defined-box').append(userDefined);
			++lockKey;
			arr.push("", "");
		});
		$('.user-defined-box').on("click", 'i', function() {
			var index = parseInt($(this).prev().attr('id').split('-')[2]);
			$(this).parent().remove();
			arr.splice(2 * index, 2);
		});


		//地区
		var province = $("#province"),
			city = $("#city"),
			town = $("#town");
		for(var i = 0; i < provinceList.length; i++){
			addEle(province, provinceList[i].name);
		}

		function addEle(ele, value){
			var optionStr = "";
			optionStr = "<option value=" + value + ">" + value + "</option>";
			ele.append(optionStr);
		}

		function removeEle(ele){
			ele.find("option").remove();
			var optionStar = "<option value=" + "请选择" + ">" + "请选择" + "</option>";
			ele.append(optionStar);
		}
		var provinceText, cityText, cityItem;
		province.on("change", function() {
			provinceText = $(this).val();
			$("#province").attr("val", provinceText);
			$.each(provinceList, function(i, item) {
				if(provinceText == item.name){
					cityItem = i;
					return cityItem
				}
			});
			removeEle(city);
			removeEle(town);
			$.each(provinceList[cityItem].cityList, function(i, item){
				addEle(city, item.name);
			});
		});
		city.on("change", function(){
			cityText = $(this).val();
			$("#city").attr("val", cityText);
			removeEle(town);
			$.each(provinceList, function(i, item){
				if(provinceText == item.name){
					cityItem = i;
					return cityItem
				}
			});
			$.each(provinceList[cityItem].cityList, function(i, item){
				if(cityText == item.name){
					for(var n = 0; n < item.areaList.length; n++){
						addEle(town, item.areaList[n])
					}
				}
			});
		});
		
		
		
		//获取默认发货地点
		/*$.ajax({
			type: "get",
			url: api+"/fh_address",
			async:true,
			data: {
				'access_token': access_token,
				'user_id': user_id
			},
			dataType: 'json'
		}).then(function(fhData){
			$('#province option:selected').text(fhData.data.province);
			$('#city option:selected').text(fhData.data.city);
			$('#town option:selected').text(fhData.data.district);
		});*/

		//上传编辑器实例化
		var ue = UE.getEditor('editor');
		
		//获取并设置选中值
		$('#fabu').on("click", function() {
	        //基本信息的信息
	        var catagory = cookieMsg.catagory,
	        	pname = cookieMsg.pname,
	        	title = $('#publish-title').val(),
	        	keyword_old = $('#publish-keyword').val(),
	        	keyword = changeDouHao(keyword_old),
	        	sku_code = $('#product-key').val();
	        //console.log(cookieMsg, user_id, access_token);
	        //规格参数的信息
			var spec = $('#spec option:selected').text(),
				deng_ji = $('#deng_ji option:selected').text(),
				jiao_shui = $('#jiao_shui option:selected').text(),
				jia_quan = $('#jia_quan option:selected').text(),
				mian_di = $('#mian_di option:selected').text(),
				han_shui_lv = $('#han_shui_lv option:selected').text(),
				xin_ban = $('#xin_ban option:selected').text(),
				ceng_shu = $('#ceng_shu option:selected').text();

			//订货的信息
			var is_manage_kc = $('.buyer-right-bottom.order .layui-input-block').eq(0).find('input[type=radio]:checked').val(),
				unit = $('.buyer-right-bottom.order .layui-input-block').eq(1).find('input[type=radio]:checked').val(),
				kc_ammount = $('.buyer-right-bottom.order .layui-input-block').eq(2).find('input').val(),
				min_qd = $('.buyer-right-bottom.order .layui-input-block').eq(3).find('input').val(),
				is_yang_pin = $('.buyer-right-bottom.order .layui-input-block').eq(4).find('input[type=radio]:checked').val(),
				price = $('.buyer-right-bottom.order .layui-input-block').eq(5).find('input').val(),
				is_yj = $('.buyer-right-bottom.order .layui-input-block').eq(6).find('input[type=radio]:checked').val(),
				fee = $('.buyer-right-bottom.order .layui-input-block').eq(7).find('input').val(),
				province = $('#province option:selected').text(),
				city = $('#city option:selected').text(),
				district = $('#town option:selected').text();
			
			//产品展示的信息
			var piccLen = $('.buyer-right-bottom.product-zhan li.picc').length;
<<<<<<< .mine
			var piccArr = [];
			for (let i=0; i < piccLen; i++) {
				var piccArrItem = $('.buyer-right-bottom.product-zhan li.picc'+(i+1)+'').find('img').attr('src');
				piccArr.push({"image_url": piccArrItem});
			}
||||||| .r394
=======
			/*var product_images = [];
			for (let i=0; i<piccLen; i++) {
				let piccc = $('.buyer-right-bottom.product-zhan li.picc').eq(0).find('img').attr('src');
				product_images.push('{"image_url": "'+ piccc +'"}');
			}*/
>>>>>>> .r417
			
			//产品详情的信息
			var arrEditor = [],
				details;//产品详情
	        arrEditor.push(UE.getEditor('editor').getContent());
	        details = arrEditor.join("\n");
			
			//上传的参数
			var publishObj = {
				'catagory': catagory,
				'pname': pname,
				'title': title,
				'keyword': keyword,
				'sku_code': sku_code,
				'spec': spec,
				'deng_ji': deng_ji,
				'jiao_shui': jiao_shui,
				'jia_quan': jia_quan,
				'mian_di': mian_di,
				'han_shui_lv': han_shui_lv,
				'xin_ban': xin_ban,
				'ceng_shu': ceng_shu,
				'parameters': [],
				'is_manage_kc': is_manage_kc,
				'unit': unit,
				'kc_ammount': kc_ammount,
				'min_qd': min_qd,
				'is_yang_pin': is_yang_pin,
				'price': price,
				'is_yj': is_yj,
				'fee': fee,
				'province': province,
				'city': city,
				'district': district,
				'product_images': piccArr,
				'details': details
			};
			
			if(lockKey == 0) {
				if(is_manage_kc == 1) {
					if('' == kc_ammount) {
						layer.msg('库存量没有填写');
						return false;
					}
					panduan();
				}else{
					panduan();
				}
				//console.log(JSON.stringify(publishObj));
				
<<<<<<< .mine
||||||| .r394
				var publishObj = {
					'access_token': access_token,
					'user_id': user_id,
					'catagory': catagory,
					'pname': pname,
					'title': title,
					'keyword': keyword,
					'sku_code': sku_code,
					'spec': spec,
					'deng_ji': deng_ji,
					'jiao_shui': jiao_shui,
					'jia_quan': jia_quan,
					'mian_di': mian_di,
					'han_shui_lv': han_shui_lv,
					'xin_ban': xin_ban,
					'ceng_shu': ceng_shu,
					'is_manage_kc': is_manage_kc,
					'unit': unit,
					'kc_ammount': kc_ammount,
					'min_qd': min_qd,
					'is_yang_pin': is_yang_pin,
					'price': price,
					'is_yj': is_yj,
					'fee': fee,
					'province': province,
					'city': city,
					'district': district,
					'details': details
				};
				console.log(publishObj);
				
=======
				var publishObj = {
					'access_token': access_token,
					'user_id': user_id,
					'catagory': catagory,
					'pname': pname,
					'title': title,
					'keyword': keyword,
					'sku_code': sku_code,
					'spec': spec,
					'deng_ji': deng_ji,
					'jiao_shui': jiao_shui,
					'jia_quan': jia_quan,
					'mian_di': mian_di,
					'han_shui_lv': han_shui_lv,
					'xin_ban': xin_ban,
					'ceng_shu': ceng_shu,
					'is_manage_kc': is_manage_kc,
					'unit': unit,
					'kc_ammount': kc_ammount,
					'min_qd': min_qd,
					'is_yang_pin': is_yang_pin,
					'price': price,
					'is_yj': is_yj,
					'fee': fee,
					'province': province,
					'city': city,
					'district': district,
					//'product_images': product_images,
					'details': details
				};
				//console.log(publishObj);
				
>>>>>>> .r417
				//发送数据到后台
				$.ajax({
					type: "post",
					url: api+"/api/FB_JHB?access_token="+ access_token +"&user_id="+ user_id,
					async: true,
					data: JSON.stringify(publishObj),
					dataType: 'json'
				}).then(function(publishData){
					console.log(publishData);
					layer.msg('发布成功');
				});
			} else {
				//自定义参数的信息
				for(let i = 0; i < lockKey; i++) {
					if($('#argue-name-' + i)) {
						//console.log(i);
						arr[2 * i] = $('#argue-name-' + i).val();
						arr[2 * i + 1] = $('#argue-value-' + i).val();
					}
				}
				brr = [];//自定义参数的数据
				for(let i = 0; i < arr.length; i++) {
					if(typeof arr[i] != 'undefined') {
						brr.push(arr[i]);
					}
				}
				
				//自定义参数的信息
				var parameters = [],
					paraObj = {};
				for (let i=0; i<brr.length; i+=2) {
					paraObj = {};
					paraObj['para_name'] = brr[i];
					paraObj['para_value'] = brr[i+1];
					parameters.push(paraObj);
				}
				
				if(is_manage_kc == 1) {
					if('' == kc_ammount) {
						layer.msg('库存量没有填写');
						return false;
					}
					panduan();
				}else{
					panduan();
				}
				//console.log(JSON.stringify(publishObj));
				publishObj.parameters = parameters;
				
<<<<<<< .mine
||||||| .r394
				var publishObj = {
					'access_token': access_token,
					'user_id': user_id,
					'catagory': catagory,
					'pname': pname,
					'title': title,
					'keyword': keyword,
					'sku_code': sku_code,
					'spec': spec,
					'deng_ji': deng_ji,
					'jiao_shui': jiao_shui,
					'jia_quan': jia_quan,
					'mian_di': mian_di,
					'han_shui_lv': han_shui_lv,
					'xin_ban': xin_ban,
					'ceng_shu': ceng_shu,
					'parameters': parameters,
					'is_manage_kc': is_manage_kc,
					'unit': unit,
					'kc_ammount': kc_ammount,
					'min_qd': min_qd,
					'is_yang_pin': is_yang_pin,
					'price': price,
					'is_yj': is_yj,
					'fee': fee,
					'province': province,
					'city': city,
					'district': district,
					'details': details
				};
				//console.log(publishObj);
				
=======
				var publishObj = {
					'access_token': access_token,
					'user_id': user_id,
					'catagory': catagory,
					'pname': pname,
					'title': title,
					'keyword': keyword,
					'sku_code': sku_code,
					'spec': spec,
					'deng_ji': deng_ji,
					'jiao_shui': jiao_shui,
					'jia_quan': jia_quan,
					'mian_di': mian_di,
					'han_shui_lv': han_shui_lv,
					'xin_ban': xin_ban,
					'ceng_shu': ceng_shu,
					'parameters': parameters,
					'is_manage_kc': is_manage_kc,
					'unit': unit,
					'kc_ammount': kc_ammount,
					'min_qd': min_qd,
					'is_yang_pin': is_yang_pin,
					'price': price,
					'is_yj': is_yj,
					'fee': fee,
					'province': province,
					'city': city,
					'district': district,
					//'product_images': product_images,
					'details': details
				};
				//console.log(publishObj);
				
>>>>>>> .r417
				//发送数据到后台
				$.ajax({
					type: "post",
					url: api+"/api/FB_JHB?access_token="+ access_token +"&user_id="+ user_id,
					async: true,
					data: JSON.stringify(publishObj),
					dataType: 'json'
				}).then(function(publishData){
					console.log(publishData);
					layer.msg('发布成功');
				});
				
			}
			
			//判断方法
			function panduan(){
				if('' == title) {
					layer.msg('标题没有填写');
				} else if('' == keyword) {
					layer.msg('关键字没有填写');
				} else if('' == spec) {
					layer.msg('规格没有选择');
				} else if('' == jiao_shui) {
					layer.msg('胶水种类没有选择');
				} else if('' == deng_ji) {
					layer.msg('产品等级没有选择');
				} else if('' == jia_quan) {
					layer.msg('甲醛释放量没有选择');
				} else if('' == mian_di) {
					layer.msg('面底没有选择');
				} else if('' == han_shui_lv) {
					layer.msg('含水率没有选择');
				} else if('' == xin_ban) {
					layer.msg('芯板等级没有选择');
				} else if('' == ceng_shu) {
					layer.msg('层数没有选择');
				} else if('' == min_qd) {
					layer.msg('起订量没有填写');
				} else if('' == price) {
					layer.msg('价格没有填写');
				} else if('' == fee) {
					layer.msg('运费没有填写');
				} else if('省份' == province) {
					layer.msg('省份没有选择');
				} else if('请选择' == city) {
					layer.msg('城市没有选择');
				} else if('请选择' == district) {
					layer.msg('区/县没有选择');
				} else if(piccLen == 0) {
					layer.msg('没有上传产品图片');
				} else if('' == details) {
					layer.msg('产品详情没有填写');
				} else if(5000 < details.length) {
					layer.msg('产品详情内容不能超过5000字符')
				}
			}
			
		});

		//左侧栏颜色改变
		$(".buyer-content .buyer-slider dl").eq(0).find("dd:nth-of-type(6)").find("a").css({
			"color": "#ff3c00"
		});
		
		//将中文逗号转换成英文逗号
		function changeDouHao(str){
			str=str.replace(/，/ig,',');
			return str;
		}
	});
});