require(['../common/common'],function(c){
    require(['jquery','template','md5','global','layu','cookie','area','slider','base'],function($,template,md5,api, layu, cookie,area){
        //产品发布页面

        layui.use(['layer', 'form', 'element'], function(){
            var layer = layui.layer
                ,form = layui.form
                ,element = layui.element;
            form.render();
            //……
            //你的代码都应该写在这里面
            var jhbCookie = $.cookie(),
                access_token = jhbCookie.access_token,
                user_id = jhbCookie.user_id;
                
            var user_id = 1000000006,
				access_token = "056f4368-690a-4820-a3ef-b6238f62d713";

            var lockKey = 0, //0表示没有自定义的参数，1表示有自定义的参数
                clickNum = 0; //表示自定义参数的数量
            var arr = [], //自定义参数数组
                brr = []; //删除undefined后的数组

            //基本信息
            var cookieMsg = $.cookie();//卖家选择的发布产品的类型和名称

            $('.seller-center-productrelease tr.one').eq(0).find('td:nth-of-type(2)').html(cookieMsg.catagory);
            $('.seller-center-productrelease tr.one').eq(1).find('td:nth-of-type(2)').html(cookieMsg.pname);
            //自定义部分
            $('.user-defined span').eq(1).on("click", function() {
                var userDefined = '<div class="user-defined-demo"><span>参数名：</span><input type="text" id="argue-name-' + lockKey + '" value="" /><span>&nbsp;&nbsp;&nbsp;&nbsp;参数值：</span><input type="text" id="argue-value-' + lockKey + '" value="" /><i class="iconfont icon-garbagecan"></i></div>'
                $('.layui-form .user-defined-box').append(userDefined);
                ++lockKey;
                arr.push("", "");
                //console.log(arr)
            });
            $('.user-defined-box').on("click", 'i', function() {
                var index = parseInt($(this).prev().attr('id').split('-')[2]);
                $(this).parent().remove();
                arr.splice(2 * index, 2);
                //console.log(arr.length)
            });

            function productdb(api,success) {

                //地区
                var province = $("#province"),
                    city = $("#city"),
                    town = $("#town");
                for(var i = 0; i < provinceList.length; i++){
                    addEle(province, provinceList[i].name);
                }

                function addEle(ele, value){
                    var optionStr = "";
                    optionStr = "<option value=" + value + ">" + value + "</option>";
                    ele.append(optionStr);
                }

                function removeEle(ele){
                    ele.find("option").remove();
                    var optionStar = "<option value=" + "请选择" + ">" + "请选择" + "</option>";
                    ele.append(optionStar);
                }
                var provinceText, cityText, cityItem;
                province.on("change", function() {
                    provinceText = $(this).val();
                    $("#province").attr("val", provinceText);
                    $.each(provinceList, function(i, item) {
                        if(provinceText == item.name){
                            cityItem = i;
                            return cityItem
                        }
                    });
                    removeEle(city);
                    removeEle(town);
                    $.each(provinceList[cityItem].cityList, function(i, item){
                        addEle(city, item.name);
                    });
                });
                city.on("change", function(){
                    cityText = $(this).val();
                    $("#city").attr("val", cityText);
                    removeEle(town);
                    $.each(provinceList, function(i, item){
                        if(provinceText == item.name){
                            cityItem = i;
                            return cityItem
                        }
                    });
                    $.each(provinceList[cityItem].cityList, function(i, item){
                        if(cityText == item.name){
                            for(var n = 0; n < item.areaList.length; n++){
                                addEle(town, item.areaList[n])
                            }
                        }
                    });
                });
                //获取默认发货地点
                $.ajax({
                    type:"get",
                    async:true,
                    dataType: "json",
                    url:api+'/api/fh_address?access_token='+ access_token +'&user_id='+ user_id,
                    contentType: "application/json; charset=utf-8",
                    success : function(msg){
                        $('#province option:selected').text(msg.data.province);
                        $('#city option:selected').text(msg.data.city);
                        $('#town option:selected').text(msg.data.district);
                    }
                });

                //库存量部分
                $('#kc_ammount').val("0");
                $('#kc_ammount').attr("disabled",true);
                $('#is_ma_kc').on('click',function () {
                    var is_kc = $(this).find('input[type=radio]:checked').val();
                    if(is_kc==0){
                        $('#kc_ammount').val("0");
                        $('#kc_ammount').attr("disabled",true);
                    }else{
                        $('#kc_ammount').val("");
                        $('#kc_ammount').attr("disabled",false);
                    }
                })

                //发布信息
                $("#release-btn").click(function() {

                    //产品展示的信息
                    var piccLen = $('.buyer-right-bottom.product-zhan li.picc').length;
                    var piccArr = [];
                    for (let i=0; i < piccLen; i++) {
                        var piccArrItem = $('.buyer-right-bottom.product-zhan li.picc'+(i+1)+'').find('img').attr('src');
                        piccArr.push({"image_url": piccArrItem});
                    }

                    //产品详情的信息
                    var arrEditor = [],
                        details;//产品详情
                    arrEditor.push(UE.getEditor('editor').getContent());
                    details = arrEditor.join("\n");

                    var insertData = {
                        "catagory":cookieMsg.catagory,
                        "pname":cookieMsg.pname,
                        "title" :$("#title").val(),
                        "keyword" : $("#keyword").val(),
                        "sku_code" : $("#sku_code").val(),
                        "spec" : $("#spec option:selected").text(),
                        "deng_ji" : $("#deng_ji option:selected").text(),
                        "pin_ban" : $("#pin_ban option:selected").text(),
                        "shu_pi" : $("#shu_pi option:selected").text(),
                        "han_shui_lv" : $("#han_shui_lv option:selected").text(),
                        "parameters" :[],
                        "is_manage_kc" : $("input[name='is_manage_kc']:checked").val(),
                        "unit" : $("input[name='unit']:checked").val(),
                        "kc_ammount" : $("#kc_ammount").val(),
                        "min_qd" : $("#min_qd").val(),
                        "is_yang_pin" : $("input[name='is_yang_pin']:checked").val(),
                        "price" : $("#price").val(),
                        "is_yj" : $("input[name='is_yj']:checked").val(),
                        "fee" : $("#fee").val(),
                        "province" : $("#province option:selected").text(),
                        "city" : $("#city option:selected").text(),
                        "district" : $("#town option:selected").text(),
                        'product_images': piccArr,
                        "details":details
                    };

                    if(lockKey == 0) {
                        if($("input[name='is_manage_kc']:checked").val() == 1) {
                            if($("#kc_ammount").val()=='') {
                                layer.alert('库存量没有填写');
                                return false;
                            }
                            sellerdb();
                        }else{
                            sellerdb();
                        }
                        //console.log(JSON.stringify(insertData));

                    } else {
                        //自定义参数的信息
                        for (let i = 0; i < lockKey; i++) {
                            if ($('#argue-name-' + i)) {
                                arr[2 * i] = $('#argue-name-' + i).val();
                                arr[2 * i + 1] = $('#argue-value-' + i).val();
                            }
                        }
                        brr = [];//自定义参数的数据
                        for (let i = 0; i < arr.length; i++) {
                            if (typeof arr[i] != 'undefined') {
                                brr.push(arr[i]);
                            }
                        }
                        //自定义参数的信息
                        var parameters = [],
                            paraObj = {};
                        for (let i = 0; i < brr.length; i += 2) {
                            paraObj = {};
                            paraObj['para_name'] = brr[i];
                            paraObj['para_value'] = brr[i + 1];
                            parameters.push(paraObj);
                        }
                        insertData.parameters = parameters;

                        if ($("input[name='is_manage_kc']:checked").val() == 1) {
                            if ($("#kc_ammount").val() == '') {
                                layer.alert('库存量没有填写');
                                return false;
                            }
                            sellerdb();
                        } else{
                            sellerdb();
                        }
                    }
                    //验证部分
                    function sellerdb(){
                        if($("#kc_ammount").val() !== ''){
                            var re =/^[0-9]*$/;
                            if(!re.test($("#kc_ammount").val()))
                            {
                                layer.alert('库存量只允许填入数字');
                                return false;
                            };
                        }
                        if($("#min_qd").val() !== ''){
                            var re =/^[0-9]*$/;
                            if(!re.test($("#min_qd").val()))
                            {
                                layer.alert('起订量只允许填入数字');
                                return false;
                            };
                        }
                        if($("#price").val() !== ''){
                            var re =/^[0-9]+([.]{1}[0-9]+){0,1}$/;
                            if(!re.test($("#price").val()))
                            {
                                layer.alert('价格只允许输入整数或小数');
                                return false;
                            };
                        }
                        if($("#fee").val() !== ''){
                            var re =/^[0-9]+([.]{1}[0-9]+){0,1}$/;
                            if(!re.test($("#fee").val()))
                            {
                                layer.alert('运费只允许输入整数或小数');
                                return false;
                            };
                        }
                        if ($("#title").val() == '') {
                            layer.alert('标题不能为空');
                            return false;
                        } else if ($("#keyword").val() == '') {
                            layer.alert("关键词不能为空");
                            return false;
                        } else if ($("#spec option:selected").val() == '') {
                            layer.alert("规格没有选择");
                            return false;
                        } else if ($("#deng_ji option:selected").text() == '') {
                            layer.alert("产品等级没有选择");
                            return false;
                        } else if ($("#pin_ban option:selected").text() == '') {
                            layer.alert("拼版没有选择");
                            return false;
                        } else if ($("#shu_pi option:selected").text() == '') {
                            layer.alert("树皮/孔洞没有选择");
                            return false;
                        } else if ($("#han_shui_lv option:selected").text() == '') {
                            layer.alert("含水率没有选择");
                            return false;
                        } else if ($("#min_qd").val() == '') {
                            layer.alert("起订量不能为空");
                            return false;
                        } else if ($("#price").val() == '') {
                            layer.alert("价格不能为空");
                            return false;
                        } else if ($("#fee").val() == '') {
                            layer.alert("运费不能为空");
                            return false;
                        }else if($("#province option:selected").text() == '省份'){
                            layer.alert("省份没有选择");
                            return false;
                        }else if($("#city option:selected").text() == '请选择'){
                            layer.alert("城市没有选择");
                            return false;
                        }else if($("#town option:selected").text() == '请选择'){
                            layer.alert("区/县没有选择");
                            return false;
                        }else if(piccLen == 0) {
                            layer.alert('没有上传产品图片');
                            return false;
                        }else if(details.length == ''){
                            layer.alert("产品详情不能为空");
                            return false;
                        }else if (details.length>5000){
                            layer.alert("产品详情内容不能超过5000字符");
                            return false;
                        }
                        //发送数据到后台
                        $.ajax({
                            type:"POST",
                            async:true,
                            data: JSON.stringify(insertData),
                            dataType: "json",
                            url:api+'/api/fb_db?access_token='+ access_token +'&user_id='+ user_id,
                            contentType: "application/json; charset=utf-8",
                            success : function(msg){
                                console.log(msg);
                                if(msg.msg =='success'){
                                    layer.alert('发布成功');
                                }else{
                                    layer.alert('发生错误！');
                                }
                            },
                            error:function(){
                                layer.alert('发生错误，请求数据失败！');
                            }
                        });
                    }
                    //console.log(JSON.stringify(insertData));
                });
            }

            productdb("http://192.168.100.90/api");

            //产品详情编辑器部分
            var ue = UE.getEditor('editor');

        });

    });
});