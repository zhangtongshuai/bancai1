require(['../common/common'],function(c){
    require(['jquery','template','md5','global','cookie','slider','base'],function($,template,md5,api){
        //联系人修改页面
        function contactAmend(api,success) {
            $("#btnSend").click(function() {
                submitIndex();
                var user_id = $.cookie('user_id'),
                    access_token = $.cookie('access_token');
                var user_id = 1000000003,
                    access_token = "da2c29b1-0db9-434d-860d-93834ca0f576";
                var insertData = {
                    "contacts" :$("#contacts").val(),
                    "phone_no" : $("#phone_no").val(),
                    "email" : $("#email").val(),
                    "user_id":user_id,
                    "access_token":access_token
                };
                $.ajax({
                    type:"POST",
                    async:false,
                    traditional :true,
                    data: JSON.stringify(insertData),
                    dataType: "json",
                    url:api+'/api/contacts',
                    contentType: "application/json; charset=utf-8",
                    success : function(msg){
                        console.log(msg);
                    },
                    error:function(){
                        alert('发生错误，请求数据失败！');
                    }
                });
            });
        }
        function submitIndex()
        {
            var oStr1 =$("#contacts").val();
            if(oStr1=='')
            {
                $("#seller-contact-amend td>span").html("联系人信息不能为空");
                $("#contacts").focus();
                return false;
            };

            var oStr2 = $("#phone_no").val();
            if(oStr2=='')
            {
                $("#seller-contact-amend td>span").html("电话号码不能为空");
                $("#phone_no").focus();
                return false;
            }else{
                var re =/^1(3|4|5|7|8)\d{9}$/;
                if(!re.test(oStr2))
                {
                    $("#seller-contact-amend td>span").html("请输入正确的手机号码");
                    $("#phone_no").focus();
                    return false;
                };
            };
            var oStr3 = $("#email").val();
            if(oStr3=='')
            {
                $("#seller-contact-amend td>span").html("电子邮箱不能为空");
                $("#email").focus();
                return false;
            }else{
                var re=/\w+\@\w+\.\w+/;
                if(!re.test(oStr3))
                {
                    $("#seller-contact-amend td>span").html("请输入带@号格式的邮箱");
                    $("#email").focus();
                    return false;
                };
            };
            $("#seller-contact-amend td>span").html("提交成功");
            $("#btnSend").attr({"disabled":"disabled"});
            return true;
        };

        contactAmend("http://192.168.100.90/api");
    });
});