require(['../common/common'],function(c){
    require(['jquery','template','slider','base'],function($,template){
        
    	/**
    	 * 数据渲染
    	 */
        
    	/**
    	 * 交互效果
    	 */
        // 首页轮播图效果
		$('#indexbaner').flexslider({
			animation: "slide",
			direction:"horizontal",
			easing:"swing"
		});
		//首页tab效果	
		 function tabs(tabTit,on,tabCon){
	        $(tabTit).children().hover(function(){
	            $(this).addClass(on).siblings().removeClass(on);
	            var index = $(tabTit).children().index(this);
	           	$(tabCon).children().eq(index).show().siblings().hide();
	    	});
		};
		tabs(".tab-hd","active",".tab-bd");



    });
});