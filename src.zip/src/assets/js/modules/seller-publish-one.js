require(['../common/common'], function(c) {
	require(['jquery', 'template', 'md5', 'global', 'layui', 'cookie', 'slider', 'base'], function($, template, md5, api, layui, cookie) {

		/**
		 * 数据渲染
		 */

		/**
		 * 交互效果
		 */
		//所有的全局变量
		var hSpan = $(".header-top-box h2").eq(1).find("span").text(), //获取消息右上角元素内容
			mcartNum = $(".header-top-box .m-cart span").text(); //获得购物车右上角元素内容
		//消息和购物车右上角的数量显示隐藏
		if(parseInt(hSpan) != 0) {
			$(".header-top-box h2").eq(1).find("span").css({
				"visibility": 'visible'
			});
		}
		if(parseInt(mcartNum) != 0) {
			$(".header-top-box .m-cart span").css({
				"display": 'inline-block'
			});
		}

		// 二维码显示隐藏
		$(".buyer-header .user-info li").eq(3).mouseenter(function() {
			$(this).find("img").removeClass("hideen");
		}).mouseleave(function() {
			$(this).find("img").addClass("hideen");
		});

		//下拉框
		var cateList = {
			"cate": [{
					name: '胶合板',
					pname: ["地板基材", "三胺基板", "三聚氰胺板", "生态板", "大芯板", "建筑模板", "家具板", "集装箱板", "清水模板", "覆膜板", "包装板", "装饰板", "异形板", "防火板", "木塑板", "LVL顺向板", "海洋板", "免漆板", "桥梁板", "木门板"],
					spec: ["1830*915*12.5", "1830*915*14.5", "1830*915*15", "1830*915*10.5", "1830*915*11", "2440*1220*18", "2440*1220*15", "2440*1220*9", "2440*1220*5", "1220*1220*13.2", "1220*920*14", "1220*920*13.2", "1220*920*12.5"]
				},
				{
					name: '密度板',
					pname: ["高密度板", "中密度板", "低密度板", "免漆密度板", "饰面密度板", "三胺密度板", "未饰面密度板"],
					spec: ["2440*1220*18", "2440*1220*15", "2440*1220*9", "2440*1220*7", "2440*1220*5"]
				},
				{
					name: '刨花板',
					pname: ["素面刨花板", "定向刨花板", "OSB欧松板", "单面三胺刨花板", "双面三胺刨花板", "空心刨花板", "免漆刨花板", "单饰面刨花板", "双饰面刨花板"],
					spec: ["2440*1220*18", "2440*1220*15", "2440*1220*9", "2440*1220*7", "2440*1220*5"]
				},
				{
					name: '单板',
					pname: ["桉木单板", "杨木单板", "松木单板", "白桦单板", "其他单板"],
					spec: ["1270*640*1.7", "1270*640*2.2", "1270*630*2.2", "1270*630*1.7", "1270*630*1.5", "1270*640*1.5", "1270*630*3.2", "1270*630*3.0", "1270*630*2.8", "1270*490*2.2", "1270*490*1.7", "970*500*1.7", "970*490*1.7", "970*640*2.2", "970*500*2.2", "970*480*2.2", "960*480*2.2", "960*480*2.0", "960*480*1.7", "960*480*1.5", "960*480*1.3"]
				},
				{
					name: '面底板',
					pname: ["桉木", "杨木", "松木", "杂木", "奥古曼", "桦木", "丝光黄桐", "铅笔柏", "山桂花", "水曲柳", "红樱桃", "冰糖果", "贝壳杉", "红橡", "克隆", "科技木", "其他"],
					spec: ["2540*1270", "1930*970", "2460*1210"]
				},
				{
					name: '实木板',
					pname: ["榉木", "榆木", "水曲柳", "橡木", "松木", "杉木", "莎木", "樟木", "刨光材板", "方板材", "方料口", "料锯材", "木方", "木条", "规格材", "方木", "方条", "干燥材", "刨光材", "干板", "烘干板", "木料", "板条", "墙板/壁板", "集成材", "指接板", "拼板", "东北材", "西南材", "海南材", "鸡翅木", "黄檀", "红檀", "紫檀", "绿檀", "花梨木", "红木", "乌木", "酸枝木"],
					spec: ["无规格"]
				}
			]
		};
		var jsonobjct = eval(cateList);
		var json = jsonobjct.cate;
		// 一级    
		var option1 = '';
		$.each(json, function(index, indexItems) {
			option1 += "<option >" + indexItems.name + "</option>";
		});
		$("#catgory").append(option1);
		$("#catgory").on("change", function() {
			$('.buyer-pinlei select').css({'color': '#333'});
			selectpname(json);
			selectpname1(json);
		});
		// 2-1 
		function selectpname(data) {
			var option2 = '';
			var selectedIndex = $("#catgory :selected").text();
			$("#pname").empty();
			$.each(data, function(index, indexItems) {
				if(indexItems.name != selectedIndex) {
					return;
				} else {
					$.each(indexItems.pname, function(index, Items) {
						option2 += "<option>" + Items + "</option>";
					});
				}
			});
			$("#pname").append(option2);
		};
		// 2-2
		function selectpname1(data) {
			var option3 = '';
			var selectedIndex = $("#name :selected").text();
			$("#spec").empty();
			$.each(data, function(index, indexItems) {
				if(indexItems.name != selectedIndex) {
					return;
				} else {
					$.each(indexItems.spec, function(index, Items) {
						option3 += "<option>" + Items + "</option>";
					});
				}

			});
			$("#spec").append(option3);
		};

		//获取并设置选中值
		$('#down-step').on("click", function() {
			var catagory = $('#catgory option:selected').text(),
				pname = $('#pname option:selected').text();
			
			$.cookie('catagory', catagory);
			$.cookie('pname', pname);
			
			switch(catagory){
				case '胶合板':
					window.location.href = 'seller-publish-jhb.html';
					break;
				
				case '密度板':
					window.location.href = 'seller-publish-mdb.html';
					break;
					
				case '刨花板':
					window.location.href = 'seller-publish-bhb.html';
					break;
					
				case '单板':
					window.location.href = 'seller-center-db.html';
					break;
					
				case '面底板':
					window.location.href = 'seller-center-mdb.html';
					break;
					
				case '实木板':
					window.location.href = 'seller-center-smb.html';
					break;
			}
		});

		//左侧栏颜色改变
		$(".buyer-content .buyer-slider dl").eq(0).find("dd:nth-of-type(6)").find("a").css({
			"color": "#ff3c00"
		});
	});
});