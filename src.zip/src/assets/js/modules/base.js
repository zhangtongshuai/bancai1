/**
 * 网站公用js
 */
require(['../common/common'],function(c){
    require(['jquery' , 'global','cookie'],function($, api){
       
    	/**
    	 * 公用效果
    	 */

    	//分类选择模拟
       $(".select_box").click(function(event){   
            event.stopPropagation();
            $(this).find(".option").toggle();
            $(this).parent().siblings().find(".option").hide();
        });
        $(document).click(function(event){
            var eo=$(event.target);
            if($(".select_box").is(":visible") && eo.attr("class")!="option" && !eo.parent(".option").length)
            $('.option').hide();                                      
        });
        /*赋值给文本框*/
        $(".option a").click(function(){
            var value=$(this).text();
            $(this).parent().siblings(".select_txt").text(value);
            $("#select_value").val(value)
        })
        
        var hSpan = $(".header-top-box h2").eq(1).find("span").text(); //获取消息右上角元素内容
			
        //消息和购物车右上角的数量显示隐藏
		if(parseInt(hSpan) != 0) {
			$(".header-top-box h2").eq(1).find("span").css({
				"visibility": 'visible'
			});
			if (parseInt(hSpan) >= 100) {
				$(".header-top-box h2").eq(1).find("span").text('99');
			}
		}

		// 二维码显示隐藏
		$(".buyer-header .user-info li").eq(3).mouseenter(function() {
			$(this).find("img").removeClass("hideen");
		}).mouseleave(function() {
			$(this).find("img").addClass("hideen");
		});
		
		//获取用户信息
		var jhbCookie = $.cookie(),
			access_token = jhbCookie.access_token,
			user_id = jhbCookie.user_id;
			
		var user_id = 1000000006,
			access_token = "056f4368-690a-4820-a3ef-b6238f62d713";

		//卖家中心产品展示图片上传
		var picLiLen = 0,
			piccI = 0, //图片的顺序标示
			pictureFile; //图片base64信息
		$('#product-zhan-up').on('change', function(event) {
			//获取图片的大小
			var fileSize = this.files[0].size;
			//图片顺序改变
			piccI ++;
			//对于图片的大小进行比较
			if(fileSize > 1 * 1024 * 1024) {
				alert("上传图片大小不能超过1M");
				return false;
			} else {
				var imageUrl = getObjectURL($(this)[0].files[0]);
				convertImgToBase64(imageUrl, function(base64Img) {
					pictureFile = base64Img;
					
					$('.buyer-right-bottom.product-zhan ul').prepend('<li class="picc picc'+piccI+'">' +
						'<div class="layui-progress"><div class="layui-progress-bar" lay-percent="0%"></div></div>'
																	+ '</li>');
					
					
					//上传图片时加载进度
					var oldProgressNum = [0, 0, 0, 0, 0, 0];//进度初始化的数
					var timerProgress = setInterval(function(){
						var progressNum = Math.ceil(Math.random()*3);
						
						oldProgressNum[piccI] += progressNum;
						
						if (oldProgressNum[piccI] >= 85) {
							clearInterval(timerProgress);
							$('.picc'+piccI+' .layui-progress div').attr('lay-percent', (oldProgressNum[piccI] + progressNum)+'%');
							$('.picc'+piccI+' .layui-progress div').css({'width': (oldProgressNum[piccI] + progressNum)+'%'});
							return false;
						}
						$('.picc'+piccI+' .layui-progress div').attr('lay-percent', (oldProgressNum[piccI] + progressNum)+'%');
						$('.picc'+piccI+' .layui-progress div').css({'width': (oldProgressNum[piccI] + progressNum)+'%'});
					}, 100);
					
					//没有上传完之前input隐藏
					$('#product-zhan-up').hide();
					
					var product_commit_obj = {
						user_id: user_id,
						access_token: access_token,
						simage: pictureFile
					};
					
					$.ajax({
						type: "post",
						url: api+"/api/Upload_Image",
						async:true,
						data: JSON.stringify(product_commit_obj),
						dataType: 'json'
					}).then(function(picUploadData){
						$('#product-zhan-up').show();
						$('.picc' + piccI).empty();
						$('.picc' + piccI).append('<img src="'+picUploadData.data.image_url+'" /><div class="cha"><i class="iconfont icon-cross"></i></div>');
					});
					
					
					picLiLen = $('.buyer-right-bottom.product-zhan ul li').length;
					//console.log(picLiLen);
					if(picLiLen == 6) {
						$('.updata-box').hide();
					}
				});
				
				event.preventDefault();
			}
		});
		$('.buyer-right-bottom.product-zhan ul').on('click', 'i', function() {
			$(this).parents('li.picc').remove();
			picLiLen = $('.buyer-right-bottom.product-zhan ul li').length;
			if(picLiLen <= 5) {
				$('.updata-box').show();
			}
		});
		
		//上传图片的方法
		function convertImgToBase64(url, callback, outputFormat) {
			var canvas = document.createElement('CANVAS');
			var ctx = canvas.getContext('2d');
			var img = new Image;
			img.crossOrigin = 'Anonymous';
			img.onload = function() {
				var width = img.width;
				var height = img.height;
				// 按比例压缩4倍
				var rate = (width < height ? width / height : height / width) / 4;
				canvas.width = width * rate;
				canvas.height = height * rate;
				ctx.drawImage(img, 0, 0, width, height, 0, 0, width * rate, height * rate);
				var dataURL = canvas.toDataURL(outputFormat || 'image/png');
				callback.call(this, dataURL);
				canvas = null;
			};
			img.src = url;
		}
		function getObjectURL(file) {
			var url = null;
			if(window.createObjectURL != undefined) { // basic
				url = window.createObjectURL(file);
			} else if(window.URL != undefined) { // mozilla(firefox)
				url = window.URL.createObjectURL(file);
			} else if(window.webkitURL != undefined) { // web_kit or chrome
				url = window.webkitURL.createObjectURL(file);
			}
			return url;
		}
		
		//地区
		var province = $("#province"),
			city = $("#city"),
			town = $("#town");
		for(var i = 0; i < provinceList.length; i++){
			addEle(province, provinceList[i].name);
		}

		function addEle(ele, value){
			var optionStr = "";
			optionStr = "<option value=" + value + ">" + value + "</option>";
			ele.append(optionStr);
		}

		function removeEle(ele){
			ele.find("option").remove();
			var optionStar = "<option value=" + "请选择" + ">" + "请选择" + "</option>";
			ele.append(optionStar);
		}
		var provinceText, cityText, cityItem;
		province.on("change", function() {
			provinceText = $(this).val();
			$("#province").attr("val", provinceText);
			$.each(provinceList, function(i, item) {
				if(provinceText == item.name){
					cityItem = i;
					return cityItem
				}
			});
			removeEle(city);
			removeEle(town);
			$.each(provinceList[cityItem].cityList, function(i, item){
				addEle(city, item.name);
			});
		});
		city.on("change", function(){
			cityText = $(this).val();
			$("#city").attr("val", cityText);
			removeEle(town);
			$.each(provinceList, function(i, item){
				if(provinceText == item.name){
					cityItem = i;
					return cityItem
				}
			});
			$.each(provinceList[cityItem].cityList, function(i, item){
				if(cityText == item.name){
					for(var n = 0; n < item.areaList.length; n++){
						addEle(town, item.areaList[n])
					}
				}
			});
		});
		//获取默认发货地点
		$.ajax({
			type: "get",
			url: api+"/api/fh_address",
			async:true,
			data: {
				'access_token': access_token,
				'user_id': user_id
			},
			dataType: 'json'
		}).then(function(fhData){
			$('#province option:selected').text(fhData.data.province);
			$('#city option:selected').text(fhData.data.city);
			$('#town option:selected').text(fhData.data.district);
		});

    });
});