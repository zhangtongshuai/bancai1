requirejs.config({
    paths:{
        'template':'../lib/template',
        'jquery':'../lib/jquery.min',
        'base':'../modules/base',
        'jquery.lazyload':'../lib/jquery.lazyload.min',
        'slider':'../lib/slider',
        'jquery.validate':'../lib/jquery.validate.min',
        'md5':'../lib/md5.min',
        'global':'../modules/global',
        'layui':'../lib/layui.all',
        'layu':'../lib/layui',
        'cookie':'../lib/jquery.cookie',
        'cooki':'../lib/js.cookie',
        'area':'../lib/area',
        'location':'../lib/location',
        'province':'../lib/province',
    },
    shim: {
        "slider": {
            deps: ['jquery']
        }
    }
});
